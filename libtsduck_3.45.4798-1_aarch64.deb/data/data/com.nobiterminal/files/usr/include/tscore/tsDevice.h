//----------------------------------------------------------------------------
//
// TSDuck - The MPEG Transport Stream Toolkit
// Copyright (c) 2005-2026, Thierry Lelegard
// BSD-2-Clause license, see LICENSE.txt file or https://tsduck.io/license
//
//----------------------------------------------------------------------------
//!
//!  @file
//!  Base class for devices which can work in non-blocking mode.
//!
//----------------------------------------------------------------------------

#pragma once
#include "tsReporterBase.h"
#include "tsAbortInterface.h"
#include "tsSysUtils.h"
#include "tsIPUtils.h"

namespace ts {
    //!
    //! Base class for devices, files, or sockets which can work in non-blocking mode.
    //! @ingroup libtscore system
    //!
    //! The methods from this class should not be used by applications. They should be
    //! used only by "reactive classes", which work in combination with an event dispatcher.
    //!
    //! The exact meaning of "non-blocking" depends on the type of device and the
    //! operating system. This is why this class shall be used by specialized classes
    //! which exactly know what they are doing.
    //!
    //! There are two distinct non-blocking I/O models:
    //!
    //! - Immediate I/O (UNIX).
    //! - Asynchronous I/O (Windows).
    //!
    //! Differences in semantics:
    //!
    //! - On UNIX systems (Linux, macOS, BSD), non-blocking means that a read or write
    //!   operation fails if it cannot be immediately served. The corresponding error is
    //!   EAGAIN. A non-blocking I/O immediately succeeds or fails.
    //!
    //! - On Windows systems, non-blocking means using "overlapped" I/O. For anyone with a
    //!   basic system culture, this means "asynchronous" I/O. An asynchronous I/O operation
    //!   can either immediately succeed or fail with error ERROR_IO_PENDING, meaning that the
    //!   operation executes in the background.
    //!
    //! Differences in usage:
    //!
    //! - Execution logic: On UNIX systems, an event dispatcher notifies the applications when an
    //!   I/O may be "possible". When notified, the application shall repeatedly read or write
    //!   all possible data, until an EAGAIN error indicates that no more I/O is immediately possible.
    //!   On Windows systems, the application starts an I/O and control immediately returns.
    //!   The I/O data exchange continues in the background. The event dispatcher notifies the
    //!   application when the I/O completes.
    //!
    //! - Data buffer usage: On UNIX, an I/O is either immediate or failed. On Windows, the
    //!   I/O is in progress as long as it is not completed. This means that, on Windows,
    //!   I/O buffers which are used for read or write must be available during the asynchronous
    //!   phase of the I/O, because the data can come in or go out at any time. On UNIX systems,
    //!   on the contrary, no buffer is used while waiting for some I/O to become possible.
    //!
    //! Important differences in canceling I/O and closing file descriptors or handles:
    //!
    //! - On UNIX, a non-blocking I/O is either immediate or failed. No I/O is ever "in progress".
    //!   Closing a file descriptor is possible at any time without restriction.
    //!
    //! - On Windows, a pending I/O can be canceled either explicitly or as the result of closing
    //!   the device handle. In that case, the I/O completion is notified later with an I/O error status.
    //!   This means that the I/O data buffer and IOSB (see below) shall remain valid as long as this
    //!   corresponding I/O completion has not been received. It is of the utmost importance that the
    //!   application keeps track of all pending asynchronous I/O and always waits for the reception of
    //!   all corresponding I/O completions before releasing the memory for the data buffers, including
    //!   when closing the device handle.
    //!
    class TSCOREDLL Device: public ReporterBase
    {
        TS_NOBUILD_NOCOPY(Device);
    public:
        //!
        //! Constructor.
        //! @param [in] report Where to report errors. The @a report object must remain valid as long as this object
        //! exists or setReport() is used with another Report object. If @a report is null, log messages are discarded.
        //! @param [in] non_blocking It true, the device is initially set in non-blocking mode.
        //!
        explicit Device(Report* report, bool non_blocking = false) : ReporterBase(report), _is_non_blocking(non_blocking) {}

        //!
        //! Constructor.
        //! @param [in] delegate Use the report of another ReporterBase. If @a delegate is null, log messages are discarded.
        //! @param [in] non_blocking It true, the device is initially set in non-blocking mode.
        //!
        explicit Device(ReporterBase* delegate, bool non_blocking = false) : ReporterBase(delegate), _is_non_blocking(non_blocking) {}

        //!
        //! Destructor.
        //!
        virtual ~Device() override;

        //!
        //! Default buffer size for receive operations.
        //! This constant is used as default value in several I/O classes.
        //!
        static constexpr size_t DEFAULT_RECEIVE_BUFFER_SIZE = 16 * 1024;

        //!
        //! Set the device in non-blocking mode.
        //!
        //! Important: Usually, this method must be called before opening the device, whatever it means.
        //! Otherwise it is ignored and the device blocking mode is unchanged.
        //!
        //! @param [in] non_blocking It true, the device is set in non-blocking mode.
        //! @return True on success, false if the device is already open and the
        //! non-blocking mode is unchanged.
        //!
        bool setNonBlocking(bool non_blocking);

        //!
        //! Check if the device is in non-blocking mode.
        //! @return True if the device is in non-blocking mode, false otherwise.
        //! @see setNonBlocking()
        //!
        bool isNonBlocking() const { return _is_non_blocking; }

        //!
        //! Check if the device is supported by a reactor for non-blocking or asynchronous I/O.
        //! @param [in] recheck If true, force a recheck. If false and the device was previously checked, return the previous cached value.
        //! @return True if the device is supported by a reactor for non-blocking or asynchronous I/O, false otherwise.
        //!
        bool isSupportedByReactor(bool recheck = false);

        //!
        //! This static method checks if a system error code means "I/O in progress" (asynchronous I/O) or "I/O would block" (non-blocking I/O).
        //! @param [in] error_code System error code.
        //! @return True if @a error_code is an in-progress/would-block one.
        //!
        static inline bool IsPendingStatus(int error_code) { return TranslateError(error_code) == SYS_PENDING_IO; }

        //!
        //! Get the underlying file descriptor or device handle.
        //! This method is reserved for low-level operations and should not be used by normal applications.
        //!
        //! On UNIX systems, sockets are standard file descriptors. On Windows systems, sockets and devices handles are two
        //! distinct types (SOCKET, an integer type, and HANDLE, a pointer type). However, SOCKET and HANDLE have the same
        //! size and can be converted between each other. In practice, all Windows device handles are pointers. When Microsoft
        //! decided to implement the BSD socket API, they needed to represent sockets as integers. The integer is simply a cast
        //! of the HANDLE pointer.
        //!
        //! In practice, the methods getHandle() and getSocket() return the same value, represented as two different portable types,
        //! SysHandleType and SysSocketType. Note that this types are defined as their real representation. On UNIX systems, both
        //! are defined as int and are compatible. However, on Windows systems, they are defined as HANDLE and SOCKET and are not
        //! compatible. So, accidentally mixing the two compiles on UNIX but not on Windows. Be careful to use the right type for
        //! the right usage.
        //!
        //! There is one important difference between getHandle() and getSocket(): the error values, SYS_HANDLE_INVALID and
        //! SYS_SOCKET_INVALID. Be careful, these constants have distinct binary values on Windows. This is the only case were it
        //! is not possible to cast between a SysHandleType value and a SysSocketType value. This is why it is recommended to always
        //! use getHandle() when a SysHandleType is required and getSocket() when a SysSocketType is required.
        //!
        //! A subclass which uses file descriptors or device handles for read, write, or both, must override the methods
        //! getReadHandle(), getWriteHandle(), or both. If the two types of operations use the same file descriptor, the two
        //! methods must return the same value.
        //!
        //! An application should call getReadHandle() for read operations and getWriteHandle() for write operations. The method
        //! getHandle() returns getReadHandle() if its returns a valid value, and getWriteHandle() otherwise.
        //!
        //! @return The underlying file descriptor or device handler. Return SYS_HANDLE_INVALID if the socket is not open.
        //!
        SysHandleType getHandle() const;

        //!
        //! Get the underlying file descriptor or device handle for read operations.
        //! Subclasses should override this method.
        //! @return The underlying file descriptor for read operations or SYS_HANDLE_INVALID if the device is not open for read.
        //! @see getHandle()
        //!
        virtual SysHandleType getReadHandle() const;

        //!
        //! Get the underlying file descriptor or device handle for write operations.
        //! Subclasses should override this method.
        //! @return The underlying file descriptor for write operations or SYS_HANDLE_INVALID if the device is not open for write.
        //! @see getHandle()
        //!
        virtual SysHandleType getWriteHandle() const;

        //!
        //! Get the underlying file descriptor or device handle as a system socket handle.
        //! @return The underlying socket descriptor. Return SYS_SOCKET_INVALID if the socket is not open.
        //! @see getHandle()
        //!
        SysSocketType getSocket() const;

        //!
        //! Get the underlying file descriptor or device handle as a system socket handle for read operations.
        //! @return The underlying file descriptor for read operations or SYS_SOCKET_INVALID if the socket is not open for read.
        //! @see getHandle()
        //!
        SysSocketType getReadSocket() const;

        //!
        //! Get the underlying file descriptor or device handle as a system socket handle for write operations.
        //! @return The underlying file descriptor for read operations or SYS_SOCKET_INVALID if the socket is not open for write.
        //! @see getHandle()
        //!
        SysSocketType getWriteSocket() const;

        //!
        //! This structure indicates the status of a non-blocking I/O.
        //! You must be a former OpenVMS expert to understand the name...
        //!
        //! The subclasses which implement non-blocking I/O should use an IOSB* parameter for any I/O operation
        //! which can be non-blocking. Typically, if the instance of the subclass is in blocking mode (the default),
        //! this parameter must be null. When the instance is in non-blocking mode, this parameter must not be null.
        //!
        //! As a general rule, when an I/O method accepts an IOSB* parameter and the I/O is pending (meaning not possible
        //! now with non-blocking I/O or in progress with asynchronous I/O), the I/O method sets the @a pending field tp
        //! true and returns a success status. The success returned status means that the I/O was successfully started and
        //! the @a pending field set to true means that the I/O is not completed yet.
        //!
        //! @see checkNonBlocking()
        //!
        class TSCOREDLL IOSB
        {
        public:
            //!
            //! This boolean indicates if the I/O is pending.
            //! - UNIX systems: The I/O would block and was not started. Retry later.
            //! - Windows systems: The I/O is started and will complete later.
            //!   Use the field @a overlap to synchronize on the I/O completion.
            //!
            bool pending = false;

            //!
            //! Current error code for the I/O.
            //! The value may evolve during the I/O, until completion.
            //!
            int error_code = SYS_SUCCESS;

            //!
            //! When @a pending is true, indicate how many bytes were successfully sent before the I/O would block.
            //! Apply to non-blocking I/O only, not asynchronous I/O.
            //!
            size_t sent_size = 0;

            //!
            //! Shared pointer to application data.
            //! This is typically set before starting the I/O at application level.
            //!
            std::shared_ptr<Object> app_data {};

            //!
            //! Shared pointer to reactive I/O data.
            //! This is typically set before starting the I/O at "reactive I/O" level.
            //!
            std::shared_ptr<Object> react_data {};

#if defined(TS_WINDOWS) || defined(DOXYGEN)
            // Memory marker to identify an overlap structure which belongs to an IOSB structure.
            // When an asynchronous I/O returns the address of an OVERLAPPED structure, check if
            // memory before the OVERLAPPED contains some magic marker.
            //! @cond nodoxygen
            volatile uint32_t iosb_marker = iosb_marker_value;
            static constexpr uint32_t iosb_marker_value = 0x494F5342; // "IOSB"
            //! @endcond

            //!
            //! OVERLAPPED structure for an asynchronous I/O (Windows-specific).
            //!
            ::OVERLAPPED overlap {};

            //!
            //! Shared pointer to asynchronous I/O data (Windows-specific).
            //! This is typically set before starting the asynchronous I/O at socket level.
            //!
            std::shared_ptr<Object> async_data {};

            //!
            //! Check if an OVERLAPPED structure is part of an IOSB.
            //! @param [in] overlap Address of an OVERLAPPED structure.
            //! @return Address of the IOSB which contains the OVERLAPPED or nullptr if @a overlap is not part of an IOSB.
            //!
            static IOSB* ParentIOSB(::OVERLAPPED* overlap);

            //! @cond nodoxygen
            IOSB();
            ~IOSB();
            //! @endcond
#else
            //! @cond nodoxygen
            IOSB() = default;
            //! @endcond
#endif
            //!
            //! Reset the IOSB for a new I/O operation.
            //!
            void reset();
        };

    protected:
        //!
        //! Check the blocking mode of a device.
        //! Called by subclass methods which are explicitly called in blocking or non-blocking mode.
        //! @param [in] non_blocking The required non-blocking mode.
        //! @param [in] opname Name of the operation, for the error message.
        //! @return True on success, false on error.
        //!
        bool checkNonBlocking(bool non_blocking, const UChar* opname);

        //!
        //! Check the blocking mode of a device.
        //! Called by subclass methods which are explicitly called in blocking or non-blocking mode.
        //! @param [in,out] iosb Address of an IOSB structure. If non-null, we are in non-blocking mode.
        //! When null, we are in blocking mode. When non-null, @a pending is reset to false and @a overlap
        //! is zeroed.
        //! @param [in] opname Name of the operation, for the error message.
        //! @return True on success, false on error.
        //!
        bool checkNonBlocking(IOSB* iosb, const UChar* opname);

        //!
        //! Check that the non-blocking mode can be set.
        //! Must be implemented by subclasses which do not support setting the non-blocking
        //! in certain states, such as after being opened. The default implementation always
        //! allows setting the non-blocking mode.
        //! @return True if setting the non-blocking mode is allowed, false otherwise.
        //!
        virtual bool allowSetNonBlocking() const;

        //!
        //! Low-level method to set the system file or socket descriptor in non-blocking mode.
        //! @param [in] non_blocking It true, the device is set in non-blocking mode.
        //! @return True on success, false on error.
        //!
        //! Summary: Do not use this method unless you exactly know what you are doing.
        //!
        //! UNIX: Depending on the way a file descriptor is created, it may be possible to specify the non-blocking mode from the
        //! beginning. Or it can be somehow inherited. However, this is not portable.
        //!
        //! Examples:
        //! - On Linux and FreeBSD, a socket can be directly created in non-blocking mode using the flag SOCK_NONBLOCK in the 'type'
        //!   parameter of the socket() system call. However, it does not work on macOS.
        //! - On macOS (and maybe FreeBSD), when a server socket is in non-blocking mode, all client session sockets which are
        //!   created by accept() are also in non-blocking mode. However, on Linux, they are in blocking mode.
        //!
        //! In all cases, it is possible to set a file descriptor in non-blocking mode at any time using the method setSystemNonBlocking().
        //! This method uses fcntl(F_SETFL) to alter the file descriptor's flags.
        //!
        //! Windows: The natural way of not being blocked on I/O on Windows is asynchronous I/O. To increase the general confusion,
        //! there is some form of non-blocking mode on Windows sockets, and only sockets, not other forms of file handles. This mode
        //! is activated using "ioctlsocket(fd, FIONBIO, &mode)". When this mode is active, socket I/O become similar to UNIX: they
        //! immediately either succeed or fail, but never block. However, there is no way to get notified when the I/O becomes possible.
        //! There is no equivalent to epoll (Linux) or kqueue (macOS and BSD). The Windows I/O Completion Ports can only work on
        //! asynchronous I/O, using OVERLAPPED structures. Because this form of non-blocking mode is mostly useless in practice, we do
        //! not use it and the method setSystemNonBlocking() does nothing on Windows.
        //!
        //! @see https://learn.microsoft.com/en-us/archive/blogs/csliu/io-concept-blockingnon-blocking-vs-syncasync
        //!
        bool setSystemNonBlocking(bool non_blocking);

        //!
        //! Generic system write operation.
        //! This is a convenience method which can be used (or not) by subclasses when the system calls
        //! write() (UNIX) or WriteFile() (Windows) are appropriate.
        //! @param [in] addr Address of the data to write.
        //! @param [in] size Size in bytes of the data to write.
        //! @param [out] written_size Actually written size in bytes.
        //! Can be less than @a size in case of error in the middle of the write.
        //! @param [in,out] iosb Address of an IOSB structure. If non-null, the stream must be in non-blocking mode.
        //! When null, the stream must be in blocking mode (the default). See the description of ts::Device::IOSB.
        //! @param [in] position This value is only used on Windows with asynchronous I/O on disk file. On Windows, when asynchronous
        //! I/O are used on random access files, the file position is not maintained. Each read or write operation is performed at
        //! the specified absolute @a position.
        //! @return Error code. When the I/O is non-blocking/asynchronous and pending, return SYS_SUCCESS and iosb->pending is true.
        //! Return SYS_EOF when it is no longer possible to write (e.g. broken pipe).
        //!
        int genericSystemWrite(const void* addr, size_t size, size_t& written_size, Device::IOSB* iosb, uint64_t position);

        //!
        //! Generic system read operation.
        //! This is a convenience method which can be used (or not) by subclasses when the system calls
        //! read() (UNIX) or ReadFile() (Windows) are appropriate.
        //! @param [out] addr Address of the buffer for the incoming data.
        //! @param [in] max_size Maximum size in bytes of the buffer.
        //! @param [out] ret_size Returned input size in bytes.
        //! If zero, end of file has been reached or an error occurred.
        //! @param [in] abort If non-zero, invoked when I/O is interrupted (in case of user-interrupt, return, otherwise retry).
        //! @param [in,out] iosb Address of an IOSB structure. If non-null, the stream must be in non-blocking mode.
        //! When null, the stream must be in blocking mode (the default). See the description of ts::Device::IOSB.
        //! @param [in] position This value is only used on Windows with asynchronous I/O on disk file. On Windows, when asynchronous
        //! I/O are used on random access files, the file position is not maintained. Each read or write operation is performed at
        //! the specified absolute @a position.
        //! @return Error code. When the I/O is non-blocking/asynchronous and pending, return SYS_SUCCESS and iosb->pending is true.
        //! Return SYS_EOF when it is no longer possible to read.
        //!
        int genericSystemRead(void* addr, size_t max_size, size_t& ret_size, const AbortInterface* abort, Device::IOSB* iosb, uint64_t position);

    private:
        bool _is_non_blocking;
        bool _reactor_supported = false;
        bool _reactor_supported_checked = false;
    };
}
