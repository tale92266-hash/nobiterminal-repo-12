//----------------------------------------------------------------------------
//
// TSDuck - The MPEG Transport Stream Toolkit
// Copyright (c) 2005-2026, Thierry Lelegard
// BSD-2-Clause license, see LICENSE.txt file or https://tsduck.io/license
//
//----------------------------------------------------------------------------
//!
//!  @file
//!  Command line arguments for --pager or --no-pager.
//!
//----------------------------------------------------------------------------

#pragma once
#include "tsOutputPager.h"

namespace ts {

    class Args;

    //!
    //! Command line arguments for @c -\-pager or @c -\-no-pager.
    //! @ingroup libtscore cmd
    //!
    class TSCOREDLL PagerArgs
    {
        TS_NOBUILD_NOCOPY(PagerArgs);
    public:
        // Public fields
        bool use_pager = false;  //!< Actually use a page process.

        //!
        //! Default constructor.
        //! @param [in] report Where to report errors. The @a report object must remain valid as long as this object
        //! exists. If @a report is null, log messages are discarded.
        //! @param [in] page_by_default If true, paging is enabled by default and option @c -\-no-pager
        //! is defined. If false, do not page by default and option @c -\-pager is defined.
        //! @param [in] stdout_only If true, use only stdout. If false, if stdout is not a terminal but
        //! stderr is one, then use stderr for paging.
        //!
        explicit PagerArgs(Report* report, bool page_by_default = false, bool stdout_only = true);

        //!
        //! Destructor.
        //!
        ~PagerArgs();

        //!
        //! Add command line option definitions in an Args.
        //! @param [in,out] args Command line arguments to update.
        //!
        void defineArgs(Args& args);

        //!
        //! Load arguments from command line.
        //! Args error indicator is set in case of incorrect arguments.
        //! @param [in,out] args Command line arguments.
        //! @return True on success, false on error in argument line.
        //!
        bool loadArgs(Args& args);

        //!
        //! Return the output device for display.
        //! @return A reference to the output device, either @c std::cout or a pager stream.
        //!
        std::ostream& output();

    private:
        bool _page_by_default = false;
        OutputPager _pager;
    };
}
