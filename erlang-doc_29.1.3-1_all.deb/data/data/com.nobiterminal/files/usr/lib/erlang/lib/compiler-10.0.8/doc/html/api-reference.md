# compiler v10.0.8 - API Reference

## Modules

- [compile](compile.md): Erlang Compiler

- Internal Modules
  - [cerl](cerl.md): Core Erlang abstract syntax trees.
  - [cerl_clauses](cerl_clauses.md): Utility functions for Core Erlang case/receive clauses.
  - [cerl_trees](cerl_trees.md): Basic functions on Core Erlang abstract syntax trees.

