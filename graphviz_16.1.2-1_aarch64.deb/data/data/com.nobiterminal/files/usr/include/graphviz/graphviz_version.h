#pragma once
#define GVPLUGIN_CONFIG_FILE "config8"
#define GVPLUGIN_VERSION 8
#define PACKAGE_BUGREPORT "https://gitlab.com/graphviz/graphviz/-/issues"
#define PACKAGE_NAME "graphviz"
#define PACKAGE_STRING "graphviz 16.1.2"
#define PACKAGE_TARNAME "graphviz"
#define PACKAGE_URL ""
#define PACKAGE_VERSION "16.1.2"

/// Graphviz version constants
///
/// These are only accurate for releases, not inter-release Graphviz commits
/// built from source.
#define GRAPHVIZ_VERSION_MAJOR 16
#define GRAPHVIZ_VERSION_MINOR 1
#define GRAPHVIZ_VERSION_PATCH 2
