# texlive.profile written on Thu Mar 21 18:50:42 2024 UTC
# It will NOT be updated and reflects only the
# installation profile at installation time.
selected_scheme scheme-full
TEXDIR /data/data/com.nobiterminal/files/usr/share/texlive/2026
TEXMFCONFIG ~/.texlive2026/texmf-config
TEXMFHOME ~/texmf
TEXMFLOCAL /data/data/com.nobiterminal/files/usr/share/texlive/texmf-local
TEXMFSYSCONFIG /data/data/com.nobiterminal/files/usr/share/texlive/2026/texmf-config
TEXMFSYSVAR /data/data/com.nobiterminal/files/usr/share/texlive/2026/texmf-var
TEXMFVAR ~/.texlive2026/texmf-var
instopt_adjustpath 1
instopt_adjustrepo 1
instopt_letter 0
instopt_portable 0
instopt_write18_restricted 1
tlpdbopt_autobackup 1
tlpdbopt_backupdir tlpkg/backups
tlpdbopt_create_formats 1
tlpdbopt_desktop_integration 1
tlpdbopt_file_assocs 1
tlpdbopt_generate_updmap 0
tlpdbopt_install_docfiles 0
tlpdbopt_install_srcfiles 0
tlpdbopt_post_code 1
tlpdbopt_sys_bin /data/data/com.nobiterminal/files/usr/bin
tlpdbopt_sys_info /data/data/com.nobiterminal/files/usr/share/info
tlpdbopt_sys_man /data/data/com.nobiterminal/files/usr/share/man
tlpdbopt_w32_multi_user 1
