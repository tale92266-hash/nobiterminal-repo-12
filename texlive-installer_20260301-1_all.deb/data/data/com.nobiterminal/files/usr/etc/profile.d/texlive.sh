export PATH=$PATH:/data/data/com.nobiterminal/files/usr/bin/texlive
export TEXMFROOT=/data/data/com.nobiterminal/files/usr/share/texlive/2026
export TEXMFLOCAL=/data/data/com.nobiterminal/files/usr/share/texlive/texmf-local
export OSFONTDIR=/data/data/com.nobiterminal/files/usr/share/fonts/TTF
export TRFONTS=/data/data/com.nobiterminal/files/usr/share/groff/{current/font,site-font}/devps
