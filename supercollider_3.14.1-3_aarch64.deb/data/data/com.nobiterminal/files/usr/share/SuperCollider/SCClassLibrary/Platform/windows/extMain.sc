+ Main {
	platformClass { ^WindowsPlatform }
}
