/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Define to 1 if you're using Bionic */
#define BIONIC_LIBC 1

/* DARWIN_VERS value for DARWIN_VERS value for Mac OS X 10.10 / iOS 8 */
/* #undef DARWIN_10_10 */

/* DARWIN_VERS value for DARWIN_VERS value for Mac OS X 10.11 / iOS 9 */
/* #undef DARWIN_10_11 */

/* DARWIN_VERS value for DARWIN_VERS value for macOS 10.12 / iOS 10 */
/* #undef DARWIN_10_12 */

/* DARWIN_VERS value for DARWIN_VERS value for macOS 10.13 / iOS 11 */
/* #undef DARWIN_10_13 */

/* DARWIN_VERS value for DARWIN_VERS value for macOS 10.14 / iOS 12 */
/* #undef DARWIN_10_14 */

/* DARWIN_VERS value for DARWIN_VERS value for macOS 10.15 / iOS 13 */
/* #undef DARWIN_10_15 */

/* DARWIN_VERS value for DARWIN_VERS value for Mac OS X 10.8 / iOS 6 */
/* #undef DARWIN_10_8 */

/* DARWIN_VERS value for DARWIN_VERS value for Mac OS X 10.9 / iOS 7 */
/* #undef DARWIN_10_9 */

/* DARWIN_VERS value for DARWIN_VERS value for macOS 11.0 / iOS 14 */
/* #undef DARWIN_11_00 */

/* DARWIN_VERS value for DARWIN_VERS value for macOS 12.0 / iOS 15 */
/* #undef DARWIN_12_00 */

/* DARWIN_VERS value for DARWIN_VERS value for macOS 13.0 / iOS 16 */
/* #undef DARWIN_13_00 */

/* DARWIN_VERS value for DARWIN_VERS value for macOS 14.0 / iOS 17 */
/* #undef DARWIN_14_00 */

/* DARWIN_VERS value for DARWIN_VERS value for macOS 15.0 / iOS 18 */
/* #undef DARWIN_15_00 */

/* DARWIN_VERS value for DARWIN_VERS value for macOS 15.4 */
/* #undef DARWIN_15_04 */

/* DARWIN_VERS value for DARWIN_VERS value for macOS / iOS 26 */
/* #undef DARWIN_26_00 */

/* Define to 1 if you're using Darwin */
/* #undef DARWIN_LIBC */

/* Darwin / Mac OS X / macOS / iOS version */
/* #undef DARWIN_VERS */

/* Disable intercept pthread_spin_lock() on MIPS32, MIPS64 and nanoMIPS. */
/* #undef DISABLE_PTHREAD_SPINLOCK_INTERCEPT */

/* configured to run as an inner Valgrind */
/* #undef ENABLE_INNER */

/* configured to build with lto link time optimisation */
/* #undef ENABLE_LTO */

/* Define to 1 if you have the new SYS___realpathat syscall. */
/* #undef FREEBSD_KQUEUEX_SYSCALL */

/* Define to 1 if you're using FreeBSD */
/* #undef FREEBSD_LIBC */

/* Define to 1 if you have the new SYS___realpathat syscall. */
/* #undef FREEBSD_REALPATHAT_SYSCALL */

/* Define to 1 if you have the new SYS_timer_fd_create syscall. */
/* #undef FREEBSD_TIMERFD_SYSCALL */

/* path to GDB */
#define GDB_PATH "/no/gdb/was/found/at/configure/time"

/* Define to 1 if index() and strlen() have been optimized heavily (x86 glibc
   >= 2.12) */
/* #undef GLIBC_MANDATORY_INDEX_AND_STRLEN_REDIRECT */

/* Define to 1 if strlen() has been optimized heavily (amd64 glibc >= 2.10) */
/* #undef GLIBC_MANDATORY_STRLEN_REDIRECT */

/* Define to 1 if you have the 'aligned_alloc' function. */
/* #undef HAVE_ALIGNED_ALLOC */

/* Define to 1 if you have the <asm/unistd.h> header file. */
#define HAVE_ASM_UNISTD_H 1

/* Define to 1 if as supports fxsave64/fxrstor64. */
/* #undef HAVE_AS_AMD64_FXSAVE64 */

/* Define to 1 if as supports floating point phased out category. */
/* #undef HAVE_AS_PPC_FPPO */

/* Define to 1 if as supports mtocrf/mfocrf. */
/* #undef HAVE_AS_PPC_MFTOCRF */

/* Define to 1 if gcc supports __sync_bool_compare_and_swap() and
   __sync_add_and_fetch() for the primary target */
#define HAVE_BUILTIN_ATOMIC 1

/* Define to 1 if g++ supports __sync_bool_compare_and_swap() and
   __sync_add_and_fetch() */
#define HAVE_BUILTIN_ATOMIC_CXX 1

/* Define to 1 if compiler provides __builtin_clz(). */
#define HAVE_BUILTIN_CLZ 1

/* Define to 1 if compiler provides __builtin_ctz(). */
#define HAVE_BUILTIN_CTZ 1

/* Define to 1 if compiler provides __builtin_popcount(). */
#define HAVE_BUILTIN_POPCOUT 1

/* Define to 1 if you have the `clockid_t' type. */
#define HAVE_CLOCKID_T 1

/* Define to 1 if you have the 'clock_gettime' function. */
#define HAVE_CLOCK_GETTIME 1

/* Define to 1 if you have the `CLOCK_MONOTONIC' constant. */
#define HAVE_CLOCK_MONOTONIC 1

/* Define to 1 if you have the 'close_range' function. */
/* #undef HAVE_CLOSE_RANGE */

/* Define to 1 if you have the 'copy_file_range' function. */
/* #undef HAVE_COPY_FILE_RANGE */

/* Define to 1 if you have a dlinfo that can do RTLD_DI_TLS_MODID. */
/* #undef HAVE_DLINFO_RTLD_DI_TLS_MODID */

/* Define to 1 if the system has the type 'Elf32_Chdr'. */
#define HAVE_ELF32_CHDR 1

/* Define to 1 if the system has the type 'Elf64_Chdr'. */
#define HAVE_ELF64_CHDR 1

/* Define to 1 if you have the <endian.h> header file. */
#define HAVE_ENDIAN_H 1

/* Define to 1 if you have the 'epoll_create' function. */
#define HAVE_EPOLL_CREATE 1

/* Define to 1 if you have the 'epoll_pwait' function. */
#define HAVE_EPOLL_PWAIT 1

/* Define to 1 if you have the 'eventfd' function. */
#define HAVE_EVENTFD 1

/* Define to 1 if you have the `eventfd_read' function. */
#define HAVE_EVENTFD_READ 1

/* Define to 1 if you have the 'exterrctl' function. */
/* #undef HAVE_EXTERRCTL */

/* Define to 1 if you have the 'fchroot' function. */
/* #undef HAVE_FCHROOT */

/* Define to 1 if you have the 'fdatasync' function. */
#define HAVE_FDATASYNC 1

/* Define to 1 if you have the 'getaddrinfo' function. */
#define HAVE_GETADDRINFO 1

/* Define to 1 if you have the 'getauxval' function. */
#define HAVE_GETAUXVAL 1

/* Define to 1 if you have the 'getpagesize' function. */
#define HAVE_GETPAGESIZE 1

/* Define to 1 if you have the 'getrandom' function. */
/* #undef HAVE_GETRANDOM */

/* Define to 1 if you have the 'getrlimitusage' function. */
/* #undef HAVE_GETRLIMITUSAGE */

/* Define to 1 if you have GNU libc C17 aligned_alloc. */
/* #undef HAVE_GNU_LIBC_C17_ALIGNED_ALLOC */

/* Define to 1 if you have the `features.h' header. */
#define HAVE_HEADER_FEATURES_H 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the 'klogctl' function. */
#define HAVE_KLOGCTL 1

/* Define to 1 if you have the 'pthread' library (-lpthread). */
#define HAVE_LIBPTHREAD 1

/* Define to 1 if you have the 'rt' library (-lrt). */
#define HAVE_LIBRT 1

/* Define to 1 if you have the 'scf' library (-lscf). */
/* #undef HAVE_LIBSCF */

/* Define to 1 if you have the 'mallinfo' function. */
#define HAVE_MALLINFO 1

/* Define to 1 if you have the 'mallinfo2' function. */
/* #undef HAVE_MALLINFO2 */

/* Define to 1 if you have the 'memchr' function. */
#define HAVE_MEMCHR 1

/* Define to 1 if you have the 'memfd_create' function. */
/* #undef HAVE_MEMFD_CREATE */

/* Define to 1 if you have the 'mempcpy' function. */
#define HAVE_MEMPCPY 1

/* Define to 1 if you have the 'memrchr' function. */
#define HAVE_MEMRCHR 1

/* Define to 1 if you have the 'memset' function. */
#define HAVE_MEMSET 1

/* Define to 1 if you have the 'mkdir' function. */
#define HAVE_MKDIR 1

/* Define to 1 if you have a working 'mmap' system call. */
#define HAVE_MMAP 1

/* Define to 1 if you have the <mqueue.h> header file. */
/* #undef HAVE_MQUEUE_H */

/* Define to 1 if you have the 'mremap' function. */
#define HAVE_MREMAP 1

/* Define to 1 if you have the 'pipe2' function. */
#define HAVE_PIPE2 1

/* Define to 1 if you have the 'ppoll' function. */
#define HAVE_PPOLL 1

/* Define to 1 if you have the 'preadv' function. */
#define HAVE_PREADV 1

/* Define to 1 if you have the 'preadv2' function. */
/* #undef HAVE_PREADV2 */

/* Define to 1 if you have the 'process_vm_readv' function. */
#define HAVE_PROCESS_VM_READV 1

/* Define to 1 if you have the 'process_vm_writev' function. */
#define HAVE_PROCESS_VM_WRITEV 1

/* Define to 1 if you have the 'pthread_barrier_init' function. */
#define HAVE_PTHREAD_BARRIER_INIT 1

/* Define to 1 if you have the 'pthread_condattr_setclock' function. */
#define HAVE_PTHREAD_CONDATTR_SETCLOCK 1

/* Define to 1 if you have the `pthread_create@glibc2.0' function. */
/* #undef HAVE_PTHREAD_CREATE_GLIBC_2_0 */

/* Define to 1 if you have the `PTHREAD_MUTEX_ADAPTIVE_NP' constant. */
/* #undef HAVE_PTHREAD_MUTEX_ADAPTIVE_NP */

/* Define to 1 if you have the `PTHREAD_MUTEX_ERRORCHECK_NP' constant. */
#define HAVE_PTHREAD_MUTEX_ERRORCHECK_NP 1

/* Define to 1 if you have the `PTHREAD_MUTEX_RECURSIVE_NP' constant. */
#define HAVE_PTHREAD_MUTEX_RECURSIVE_NP 1

/* Define to 1 if you have the 'pthread_mutex_timedlock' function. */
#define HAVE_PTHREAD_MUTEX_TIMEDLOCK 1

/* Define to 1 if pthread_mutex_t has a member __data.__kind. */
/* #undef HAVE_PTHREAD_MUTEX_T__DATA__KIND */

/* Define to 1 if pthread_mutex_t has a member called __m_kind. */
/* #undef HAVE_PTHREAD_MUTEX_T__M_KIND */

/* Define to 1 if you have the `PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP'
   constant. */
#define HAVE_PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP 1

/* Define to 1 if you have the `pthread_rwlock_t' type. */
#define HAVE_PTHREAD_RWLOCK_T 1

/* Define to 1 if you have the 'pthread_rwlock_timedrdlock' function. */
#define HAVE_PTHREAD_RWLOCK_TIMEDRDLOCK 1

/* Define to 1 if you have the 'pthread_rwlock_timedwrlock' function. */
#define HAVE_PTHREAD_RWLOCK_TIMEDWRLOCK 1

/* Define to 1 if you have the 'pthread_setname_np' function. */
#define HAVE_PTHREAD_SETNAME_NP 1

/* Define to 1 if you have the 'pthread_spin_lock' function. */
#define HAVE_PTHREAD_SPIN_LOCK 1

/* Define to 1 if you have the 'pthread_yield' function. */
/* #undef HAVE_PTHREAD_YIELD */

/* Define to 1 if you have the `PTRACE_GETREGS' ptrace request. */
/* #undef HAVE_PTRACE_GETREGS */

/* Define to 1 if you have the 'pwritev' function. */
#define HAVE_PWRITEV 1

/* Define to 1 if you have the 'pwritev2' function. */
/* #undef HAVE_PWRITEV2 */

/* Define to 1 if you have the 'rawmemchr' function. */
/* #undef HAVE_RAWMEMCHR */

/* Define to 1 if you have the 'readlinkat' function. */
#define HAVE_READLINKAT 1

/* Define to 1 if you have the 'reallocarray' function. */
/* #undef HAVE_REALLOCARRAY */

/* Define to 1 if you have the 'sbrk' function. */
#define HAVE_SBRK 1

/* Define to 1 if you have the 'semtimedop' function. */
/* #undef HAVE_SEMTIMEDOP */

/* Define to 1 if you have the 'sem_clockwait_np' function. */
/* #undef HAVE_SEM_CLOCKWAIT_NP */

/* Define to 1 if you have the 'sem_timedwait' function. */
#define HAVE_SEM_TIMEDWAIT 1

/* Define to 1 if you have the 'setcontext' function. */
/* #undef HAVE_SETCONTEXT */

/* Define to 1 if you have the 'setcred' function. */
/* #undef HAVE_SETCRED */

/* Define to 1 if libstd++ supports annotating shared pointers */
/* #undef HAVE_SHARED_POINTER_ANNOTATION */

/* Define to 1 if you have the 'signalfd' function. */
#define HAVE_SIGNALFD 1

/* Define to 1 if you have the 'sigwaitinfo' function. */
#define HAVE_SIGWAITINFO 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the 'stpncpy' function. */
#define HAVE_STPNCPY 1

/* Define to 1 if you have the 'strchr' function. */
#define HAVE_STRCHR 1

/* Define to 1 if you have the 'strchrnul' function. */
#define HAVE_STRCHRNUL 1

/* Define to 1 if you have the 'strdup' function. */
#define HAVE_STRDUP 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the 'strlcat' function. */
#define HAVE_STRLCAT 1

/* Define to 1 if you have the 'strlcpy' function. */
#define HAVE_STRLCPY 1

/* Define to 1 if you have the 'strndup' function. */
#define HAVE_STRNDUP 1

/* Define to 1 if you have the 'strpbrk' function. */
#define HAVE_STRPBRK 1

/* Define to 1 if you have the 'strrchr' function. */
#define HAVE_STRRCHR 1

/* Define to 1 if you have the 'strstr' function. */
#define HAVE_STRSTR 1

/* Define to 1 if <sys/stat.h> declares struct statx. */
#define HAVE_STRUCT_STATX_IN_SYS_STAT_H 1

/* Define to 1 if you have the 'swapcontext' function. */
/* #undef HAVE_SWAPCONTEXT */

/* Define to 1 if you have the 'syscall' function. */
#define HAVE_SYSCALL 1

/* Define to 1 if sys/crypto/ioctl.h is available. */
/* #undef HAVE_SYS_CRYPTO_IOCTL_H */

/* Define to 1 if you have the <sys/endian.h> header file. */
#define HAVE_SYS_ENDIAN_H 1

/* Define to 1 if you have the <sys/epoll.h> header file. */
#define HAVE_SYS_EPOLL_H 1

/* Define to 1 if you have the <sys/eventfd.h> header file. */
#define HAVE_SYS_EVENTFD_H 1

/* Define to 1 if you have the <sys/klog.h> header file. */
#define HAVE_SYS_KLOG_H 1

/* Define to 1 if you have the <sys/lgrp_user_impl.h> header file. */
/* #undef HAVE_SYS_LGRP_USER_IMPL_H */

/* Define to 1 if you have the <sys/param.h> header file. */
#define HAVE_SYS_PARAM_H 1

/* Define to 1 if you have the <sys/poll.h> header file. */
#define HAVE_SYS_POLL_H 1

/* Define to 1 if you have the <sys/prctl.h> header file. */
#define HAVE_SYS_PRCTL_H 1

/* Define to 1 if you have the <sys/signalfd.h> header file. */
#define HAVE_SYS_SIGNALFD_H 1

/* Define to 1 if you have the <sys/signal.h> header file. */
#define HAVE_SYS_SIGNAL_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/syscall.h> header file. */
#define HAVE_SYS_SYSCALL_H 1

/* Define to 1 if you have the <sys/sysnvl.h> header file. */
/* #undef HAVE_SYS_SYSNVL_H */

/* Define to 1 if you have the <sys/time.h> header file. */
#define HAVE_SYS_TIME_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if <sys/user.h> defines struct user_regs_struct */
#define HAVE_SYS_USER_REGS 1

/* Define to 1 if you have the 'timer_delete' function. */
#define HAVE_TIMER_DELETE 1

/* can use __thread to define thread-local variables */
#define HAVE_TLS 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if you have a usable <linux/futex.h> header file. */
#define HAVE_USABLE_LINUX_FUTEX_H 1

/* Define to 1 if you have the 'utimensat' function. */
#define HAVE_UTIMENSAT 1

/* Define to 1 if you have the 'wcpncpy' function. */
#define HAVE_WCPNCPY 1

/* Define to 1 if you have the 'wcsncpy' function. */
#define HAVE_WCSNCPY 1

/* Define to 1 if you have the 'wcsxfrm' function. */
#define HAVE_WCSXFRM 1

/* Define to 1 if you have the illumos `spawn' syscall. */
/* #undef ILLUMOS_SPAWN_SYSCALL */

/* Define to 1 if you're using Musl libc */
/* #undef MUSL_LIBC */

/* Name of package */
#define PACKAGE "valgrind"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "valgrind-users@lists.sourceforge.net"

/* Define to the full name of this package. */
#define PACKAGE_NAME "Valgrind"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "Valgrind 3.28.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "valgrind"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "3.28.0"

/* SDK_VERS value for Xcode SDK macOS 10.13 / iOS 11 */
/* #undef SDK_10_13 */

/* SDK_VERS value for Xcode SDK macOS 10.14 / iOS 12 */
/* #undef SDK_10_14 */

/* SDK_VERS value for Xcode SDK macOS 10.14.6 / iOS 12 */
/* #undef SDK_10_14_6 */

/* SDK_VERS value for Xcode SDK macOS 10.15 / iOS 13 */
/* #undef SDK_10_15 */

/* SDK_VERS value for Xcode SDK earlier than macOS 10.13 / iOS 11 */
/* #undef SDK_10_XX */

/* SDK_VERS value for Xcode SDK macOS 11.0 / iOS 14 */
/* #undef SDK_11_0 */

/* SDK_VERS value for Xcode SDK macOS 12.0 / iOS 15 */
/* #undef SDK_12_0 */

/* SDK_VERS value for Xcode SDK macOS 13.0 / iOS 16 */
/* #undef SDK_13_0 */

/* SDK_VERS value for Xcode SDK macOS 14.0 / iOS 17 */
/* #undef SDK_14_0 */

/* SDK_VERS value for Xcode SDK macOS 15.0 / iOS 18 */
/* #undef SDK_15_0 */

/* SDK_VERS value for Xcode SDK macOS / iOS 26 */
/* #undef SDK_26_0 */

/* SDK version */
/* #undef SDK_VERS */

/* Define to 1 if you have the `A_GETSTAT' and `A_SETSTAT' constants. */
/* #undef SOLARIS_AUDITON_STAT */

/* Define to 1 if you have the new `execve' syscall which accepts flags. */
/* #undef SOLARIS_EXECVE_SYSCALL_TAKES_FLAGS */

/* Define to 1 if fpregset_t defines struct _fpchip_state */
/* #undef SOLARIS_FPCHIP_STATE_TAKES_UNDERSCORE */

/* Define to 1 if you have the new `frealpathat' syscall. */
/* #undef SOLARIS_FREALPATHAT_SYSCALL */

/* Define to 1 if you have the new `gethrt' fasttrap. */
/* #undef SOLARIS_GETHRT_FASTTRAP */

/* Define to 1 if you have the new `getrandom' syscall. */
/* #undef SOLARIS_GETRANDOM_SYSCALL */

/* Define to 1 if you have the new `get_zone_offset' fasttrap. */
/* #undef SOLARIS_GETZONEOFFSET_FASTTRAP */

/* Default platform for Valgrind launcher. */
/* #undef SOLARIS_LAUNCHER_DEFAULT_PLATFORM */

/* Define to 1 if you have the new `lwp_name' syscall. */
/* #undef SOLARIS_LWP_NAME_SYSCALL */

/* Define to 1 if you have the new `lwp_sigqueue' syscall. */
/* #undef SOLARIS_LWP_SIGQUEUE_SYSCALL */

/* Define to 1 if you have the new `lwp_sigqueue' syscall which accepts pid.
   */
/* #undef SOLARIS_LWP_SIGQUEUE_SYSCALL_TAKES_PID */

/* Define to 1 if you have the `MODNVL_CTRLMAP' through `MODDEVINFO_CACHE_TS'
   constants. */
/* #undef SOLARIS_MODCTL_MODNVL */

/* Define to 1 if you have the new `accept' syscall. */
/* #undef SOLARIS_NEW_ACCEPT_SYSCALL */

/* Define to 1 if you have the new `pipe' syscall. */
/* #undef SOLARIS_NEW_PIPE_SYSCALL */

/* Define to 1 if nscd attaches to /system/volatile/name_service_door. */
/* #undef SOLARIS_NSCD_DOOR_SYSTEM_VOLATILE */

/* Define to 1 if you have the old Solaris syscalls. */
/* #undef SOLARIS_OLD_SYSCALLS */

/* Define to 1 if you have /proc/self/cmdline. */
/* #undef SOLARIS_PROC_CMDLINE */

/* Define to 1 if you have the `prxregset_t' type. */
/* #undef SOLARIS_PRXREGSET_T */

/* Define to 1 if you have the `PSET_GET_NAME' constants. */
/* #undef SOLARIS_PSET_GET_NAME */

/* Define to 1 if PT_SUNWDTRACE program header provides just an initial thread
   pointer for libc. */
/* #undef SOLARIS_PT_SUNDWTRACE_THRP */

/* Version number of the repository door cache protocol. */
/* #undef SOLARIS_REPCACHE_PROTOCOL_VERSION */

/* Define to 1 if you have the new `sysstat' segment reservation. */
/* #undef SOLARIS_RESERVE_SYSSTAT_ADDR */

/* Define to 1 if you have the new `sysstat_zone' segment reservation. */
/* #undef SOLARIS_RESERVE_SYSSTAT_ZONE_ADDR */

/* Define to 1 if you have the schedctl page executable. */
/* #undef SOLARIS_SCHEDCTL_PAGE_EXEC */

/* Define to 1 if you have the `IPC_XSTAT64', `SHMADV', `SHM_ADV_GET',
   `SHM_ADV_SET' and `SHMGET_OSM' constants. */
/* #undef SOLARIS_SHM_NEW */

/* Define to 1 if you have the `spawn' syscall. */
/* #undef SOLARIS_SPAWN_SYSCALL */

/* Define to 1 if you have the `system_stats' syscall. */
/* #undef SOLARIS_SYSTEM_STATS_SYSCALL */

/* Define to 1 if you have the `TNDB_GET_TNIP' constant. */
/* #undef SOLARIS_TNDB_GET_TNIP */

/* Define to 1 if you have the `TSOL_GETCLEARANCE' and `TSOL_SETCLEARANCE'
   constants. */
/* #undef SOLARIS_TSOL_CLEARANCE */

/* Define to 1 if you have the `utimensat' syscall. */
/* #undef SOLARIS_UTIMENSAT_SYSCALL */

/* Define to 1 if you have the `utimesys' syscall. */
/* #undef SOLARIS_UTIMESYS_SYSCALL */

/* Define to 1 if you have the new `uuidsys' syscall. */
/* #undef SOLARIS_UUIDSYS_SYSCALL */

/* Define to 1 if you have the `ZONE_LIST_DEFUNCT' and `ZONE_GETATTR_DEFUNC'
   constants. */
/* #undef SOLARIS_ZONE_DEFUNCT */

/* Define to 1 if all of the C89 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Version number of package */
#define VERSION "3.28.0"

/* Temporary files directory */
#define VG_TMPDIR "/data/data/com.nobiterminal/files/usr/tmp"

/* Define as 'int' if <sys/types.h> doesn't define. */
/* #undef gid_t */

/* Define to 'long int' if <sys/types.h> does not define. */
/* #undef off_t */

/* Define as 'unsigned int' if <stddef.h> doesn't define. */
/* #undef size_t */

/* Define as 'int' if <sys/types.h> doesn't define. */
/* #undef uid_t */
