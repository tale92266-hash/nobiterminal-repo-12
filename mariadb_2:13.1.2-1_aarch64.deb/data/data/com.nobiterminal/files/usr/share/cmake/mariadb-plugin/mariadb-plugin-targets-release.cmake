#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "mysqlservices" for configuration "Release"
set_property(TARGET mysqlservices APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(mysqlservices PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-android/libmysqlservices.a"
  )

list(APPEND _cmake_import_check_targets mysqlservices )
list(APPEND _cmake_import_check_files_for_mysqlservices "${_IMPORT_PREFIX}/lib/aarch64-linux-android/libmysqlservices.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
