HDF5 version 2.3.0 released on 2026-11-25

# 🔺 HDF5 Changelog
All notable changes to this project will be documented in this file. This document describes the differences between this release and the previous
HDF5 release, platforms tested, and known problems in this release.

For releases prior to version 2.0.0, please see the release.txt file and for more details check the HISTORY*.txt files in the HDF5 source.

# 🔗 Quick Links
* [HDF5 documentation](https://support.hdfgroup.org/documentation/hdf5/latest/)
* [Official HDF5 releases](https://support.hdfgroup.org/downloads/index.html)
* [Changes from Release to Release and New Features in the HDF5-2.x.y](https://support.hdfgroup.org/releases/hdf5/documentation/release_specific_info.md)
* [Getting help, questions, or comments](https://github.com/HDFGroup/hdf5#help-and-support)

## 📖 Contents
* [Executive Summary](CHANGELOG.md#execsummary)
* [Breaking Changes](CHANGELOG.md#%EF%B8%8F-breaking-changes)
* [Deprecations](CHANGELOG.md#-deprecations)
* [New Features & Improvements](CHANGELOG.md#-new-features--improvements)
* [Bug Fixes](CHANGELOG.md#-bug-fixes)
* [Support for new platforms and languages](CHANGELOG.md#-support-for-new-platforms-and-languages)
* [Platforms Tested](CHANGELOG.md#%EF%B8%8F-platforms-tested)
* [Known Problems](CHANGELOG.md#-known-problems)

# 🔆 Executive Summary: HDF5 Version 2.3.0


## Performance Enhancements:


## Significant Advancements:

- Added support for internally concurrent multithreaded reads of chunked datasets

- Added a new version of the `H5Z_class_t` structure, `H5Z_class3_t`, to include feature flags

- Added a Linux binary which runs with glibc 2.28 and newer

## Enhanced Features:

- Updated the ROS3 VFD to read an alternate endpoint URL from the AWS configuration file

- Made several improvements to the installed CMake package configuration files, including introducing new linkage-agnostic CMake target names (`hdf5::hdf5`, `hdf5::hdf5_hl`, `hdf5::hdf5_fortran`, etc.) for compatibility with CMake's FindHDF5 module

## Java Enhancements:


## Acknowledgements:

We would like to thank the many HDF5 community members who contributed to this release of HDF5.

## Changelog and release information:

The full list of changes in this release can be found in [CHANGELOG.md](https://github.com/HDFGroup/hdf5/blob/2.3.0/release_docs/CHANGELOG.md).

Information about a specific HDF5 release can be found at https://support.hdfgroup.org/documentation/hdf5/latest/release_specific_info.html.

# ⚠️ Breaking Changes

- When a `find_package (HDF5 ...)` call within a CMake project uses HDF5's `hdf5-config.cmake`
  configuration file (a Config mode search), requesting both "shared" and "static" components
  simultaneously will now fail. Only one of the "shared" or "static" components should be requested
  when locating HDF5. Consequently, the `HDF5_LIB_TYPE` CMake variable set by the configuration file
  will only be set to one of "shared" or "static", depending on the requested library type, rather
  than potentially being a list of both. For the time being, both sets of HDF5's "-shared" and
  "-static" CMake targets will continue to be available after the `find_package (HDF5 ...)` call,
  regardless of which library type was requested.

- When a `find_package (HDF5 ...)` call within a CMake project uses HDF5's `hdf5-config.cmake`
  configuration file (a Config mode search), the consuming project may now be required to have
  one or more CMake languages enabled, depending on the specific COMPONENTS requested. HDF5's
  configuration file previously enabled these languages automatically with calls to
  `enable_language()`, but these calls were removed in favor of checking the enabled languages
  and issuing an error if required languages aren't enabled.

- The static HDF5 library now uses the threads library in default builds wherever a threading
  package is available. Previously, it was only used in builds with thread-safety, concurrency,
  or the Subfiling VFD. Projects that link the static library without CMake or pkg-config must
  include the threads link flag (usually `-pthread`) on systems where the thread functions aren't
  part of the C library, (e.g. Linux with glibc < 2.34). HDF5's pkg-config file already listed this
  flag, but default builds did not require it until now. The flag is supplied by
  `pkg-config --static --libs hdf5`.

### The installed CMake package now prefers the shared libraries when no linkage is requested

   A `find_package(HDF5 NAMES hdf5 CONFIG)` call that requests neither the `static` nor the `shared` component previously resolved to the static libraries of an installation providing both, and only fell back to shared when no static libraries were installed. That preference is now reversed: shared is used when available, with static as the fallback. Setting `HDF5_USE_STATIC_LIBRARIES` before the call now selects the static libraries, matching the behavior of CMake's `FindHDF5` module.

   The preference decides which `HDF5_<lang>_<LINKAGE>_LIBRARY` variables and Fortran module directory the call sets, as well as the linkage the new `hdf5::` targets refer to, so a project that relied on the previous default and did not request a linkage will now link the shared libraries. Such a project should request the `static` component explicitly or set `HDF5_USE_STATIC_LIBRARIES`. Calls that already request a `static` or `shared` component are unaffected.

# 🪦 Deprecations

### Deprecated the linkage-qualified CMake target names

   The `hdf5-shared` / `hdf5-static` targets, their `_hl`, `_cpp`, `_hl_cpp`, `_fortran` and `_hl_fortran` counterparts, and the `HDF5_<lang>_<LINKAGE>_LIBRARY` variables are deprecated in favor of the stable `hdf5::` target names described under Configuration below. They will be removed in a future major release, so new projects should link `hdf5::hdf5` and friends, and existing projects should migrate to the new names when convenient. See `docs/USING_HDF5_CMake.md` for the mapping from old names to new ones.


# 🚀 New Features & Improvements

## Configuration

### Stopped publishing .deb and .rpm files with the release

   The `.deb` and `.rpm` files built on Ubuntu were not real distribution packages: they
   were CPack output with the layout and dependencies of the tarball, and they conflicted
   with the HDF5 packages the distributions themselves ship. Native packages come from the
   distributions and from the HDF Group's build service project instead. The Linux tarballs
   are unaffected.

### Added a Linux binary that runs on glibc 2.28 and newer

   The released Linux binary was built on Ubuntu 24.04 and requires glibc 2.38, so it does
   not run on RHEL 9, Amazon Linux 2023, SLES 15, Debian 12 or Ubuntu 22.04. Releases now
   also carry `hdf5-<version>-linux-x86_64_gcc.tar.gz`, built in an AlmaLinux 8 container
   with gcc-toolset-14. **It requires glibc 2.28 or newer**, which covers RHEL 8+, SLES 15,
   Debian 10+, Ubuntu 20.04+ and Amazon Linux 2023. zlib and libaec are linked statically,
   as in the other binaries, so it needs nothing from the system but libc and libm. CI
   fails the build if that requirement ever rises.

### Re-added HDF5_ENABLE_THREADS option

   The HDF5_ENABLE_THREADS option now controls whether the library builds in any
   threading support, and is enabled by default. Disabling this option will
   allow the user to avoid the overhead associated with thread-specific-variable
   lookups, but will also disable internal concurrency features (see
   H5TSset_internal_threads()). It is an error for this option to be disabled
   while HDF5_ENABLE_THREADSAFE or HDF5_ENABLE_CONCURRENCY are enabled.

   This option was previously present but was non-functional, and was removed in
   2.0.0.

### Built the library's internal thread pool by default

   The internal thread pool lets the library parallelize the internals of a
   single API call using its own worker threads. It adds no application
   threads, so it is not a build-time choice exposed through CMake. It is built
   in wherever a threading package is available, except in a static library on
   Windows.

   Note that nothing in the library is threaded until the application enables it via
   H5TSset_internal_threads().

   Linking the static library now requires the threads library on some systems; see
   Breaking Changes.

   The internal thread pool can now be used with the high-level, Fortran, Java and C++ interfaces.

### Various improvements in installed CMake package configuration file

   - Fixed `find_dependency()` calls so that `PRIVATE`-linked libraries are only propagated as
     transitive link requirements for static library targets (Fixes GitHub issue #6347)
   - Added missing `find_dependency()` calls for some `PRIVATE`-linked libraries
   - Fixed an issue where `find_package()` for parallel-enabled HDF5 installations may fail when
     trying to locate MPI Fortran support, even if HDF5 Fortran support isn't requested (Fixes
     GitHub issue #6366)
   - Fixed an issue where the `HDF5_LIB_TYPE` CMake variable would be undefined if some HDF5
     components were requested in a `find_package()` call, but "shared" or "static" was not requested
   - Removed a call to `enable_language()` in favor of checking the currently enabled CMake languages
     and failing if a required language isn't enabled
   - Added a CMake variable for the enabled/disabled status of the "digitally signed plugins"
     feature
   - Fixed the CMake variable for the enabled/disabled status of the `HDF5_DIMENSION_SCALES_NEW_REF`
     option
   - Reduced the scope of some temporary variables and modifications so they don't propagate to
     consuming CMake projects

### Added stable, linkage-agnostic CMake target names to the installed package

   Downstream projects can now link `hdf5::hdf5`, `hdf5::hdf5_hl`, `hdf5::hdf5_cpp`, `hdf5::hdf5_hl_cpp`, `hdf5::hdf5_fortran` and `hdf5::hdf5_hl_fortran` instead of the linkage-qualified `hdf5-shared` and `hdf5-static` targets, along with `hdf5::<tool>` for each installed tool. The names do not encode whether the library is static or shared, so the same project file works against a static installation, a shared one, or one providing both. These are the names CMake's own `FindHDF5` module provides, so a project using them no longer needs different code depending on whether HDF5 was located through `FindHDF5` or through HDF5's `hdf5-config.cmake`. The targets refer to whichever linkage `find_package()` resolved (see Breaking Changes). The existing `hdf5-shared` / `hdf5-static` targets and the `HDF5_<lang>_<LINKAGE>_LIBRARY` variables are otherwise unchanged, and the public names are aliases onto those same targets, so a project naming both on its link line still gets a single library.

## Library

### Removed API lock for memory management wrappers

   The HDF5 library no longer acquires the global thread lock when entering
   H5allocate_memory(), H5resize_memory(), and H5free_memory(). This allows
   multiple threads to access these functions concurrently.

### Added new VFD feature flag

   Added a new Virtual File Driver (VFD) feature flag,
   H5FD_FEAT_READWRITE_NO_H5_CALLS. This flag should be set when the read and
   write callbacks do not make any HDF5 calls except for H5OPEN.

### Added new version of H5Z_class_t, H5Z_class3_t, to include feature flags

   Added a new version of the H5Z_class_t struct, H5Z_class3_t. This version has
   a new field, feature_flags, which indicates to the library which features the
   plugin supports. The currently supported flags are
   H5Z_FEAT_FILTER_THREADSAFE, which should be set when the filter callback is
   threadsafe, and H5Z_FEAT_FILTER_NO_H5_CALLS, which should be set when the
   filter makes no HDF5 calls except for H5OPEN, H5allocate_memory(),
   H5resize_memory(), H5free_memory(), and all H5E functions.

### Added support for internally concurrent multithreaded reads of chunked datasets

   Added 3 new functions to support this: H5TSset_internal_threads(),
   H5Pset_io_threads(), and H5Pget_io_threads().

   This feature internally parallelizes read operations on chunked datasets.
   H5TSset_internal_threads() is used to enable the feature globally, while
   H5Pset_io_threads() can be used to disable the feature on a per-operation
   basis. These functions are only available when the library is built with a
   threading package; see the Configuration section above. When performing an
   internally threaded read, the library will, when possible, concurrently read
   from disk, unfilter, and scatter to memory all chunks in a read operation on
   a chunked dataset. Currently only the filter operations are executed
   concurrently, the others are serialized.


## Parallel Library

## Fortran Library

## C++ Library

## Java Library

## Tools

## High-Level APIs

## C Packet Table API

## Internal header file

## Documentation


# 🪲 Bug Fixes

## Library

### Fixed an assertion failure when a filter pipeline contains `H5Z_MAX_NFILTERS` filters

   An `assert()` in the internal function `H5Z_pipeline()` caused a crash in debug builds
   of the library when a filter pipeline contained exactly `H5Z_MAX_NFILTERS` filters. The
   HDF5 file format specification documents that 32, the number which `H5Z_MAX_NFILTERS` is
   currently mapped to, is the maximum number of filters that a filter pipeline can contain,
   so the `assert()` has been fixed for this case.

   Fixes GitHub issue #6655

### ROS3 VFD now reads an alternate endpoint URL from the AWS configuration file

   The ROS3 VFD resolved an alternate S3 endpoint URL only from a file access
   property list or from the `AWS_ENDPOINT_URL_S3` and `AWS_ENDPOINT_URL`
   environment variables. An `endpoint_url` setting in the shared AWS configuration
   file (`~/.aws/config`) was ignored, even though the AWS CLI and the AWS SDKs
   honor it, so a configuration that worked with other AWS tooling was inactive
   under the ROS3 VFD.

   The VFD now follows the AWS specified order when parsing for the `endpoint_url`
   entry under the `s3` key of the `[services ...]` section named by the active
   profile, followed by the `endpoint_url` entry of the profile itself. A file
   access property list and the two environment variables continue to take
   precedence, in that order.

   Note that this changes where requests are sent for an application that has an
   `endpoint_url` configured in the AWS configuration file but the ROS3 VFD ignored
   it until now. Setting the `AWS_IGNORE_CONFIGURED_ENDPOINT_URLS` environment
   variable, or the `ignore_configured_endpoint_urls` entry of the active profile,
   to "true" restores the previous behavior by suppressing every endpoint source
   except the file access property list.

   Fixes GitHub issue #6739

### Fixed crashes when using variable-length data after closing another handle of the same dataset

   A dataset's datatype is shared by all open handles of the dataset, and its
   variable-length types refer to the file of the handle that opened the dataset first.
   After that file handle was closed, other handles of the same dataset, e.g., from
   opening the same file twice, still converted variable-length data with the closed
   file, which crashed in `H5F_addr_decode()`. `H5T_patch_vlen_file()` repaired the file
   only for a variable-length type at the top level of the datatype, and only when reading
   or writing data, but not for variable-length types nested in compound or array types,
   or when converting a variable-length fill value in `H5Dget_create_plist()` or while
   initializing storage, e.g., in `H5Dset_extent()`. Opening a netCDF-4 file with string
   variables calls `H5Dget_create_plist()`, so this crashed netCDF-C and netCDF4-python
   when a file was opened again after closing one of several handles to it.
   `H5T_patch_vlen_file()` now repairs nested variable-length types as well, and is also
   called before converting fill values.

   Fixes GitHub issue #6721

### Fixed set_local and filter callbacks being called for filters whose can_apply callback returns false

   Fixed library to no longer execute the set_local and filter callbacks when an optional
   filter plugin's can_apply callback returned false, to match the documented behavior.

### Removed max cache entry size assertion

   Removed H5C_MAX_ENTRY_SIZE which caused an assertion to fail if a metadata cache entry
   was larger than 32 MiB. This was meant to detect corruption, not actually impose a
   limit on the maximum size of a metadata cache entry. This can cause assertion failures
   in legitimate use cases. While we could simply increase the size, there are already
   checks for a cache entry that is too big to fit in the file, and an assertion is
   inappropriate to check for file corruption, so this check has been removed.

### Fixed H5Pmodify_filter() writing past the filter pipeline for a filter not in it

   `H5Pmodify_filter()` returned success when the requested filter was not in the pipeline, and wrote the new flags and client data into the slot one past the last used entry. When the pipeline already held `H5Z_MAX_NFILTERS` filters, that write went past the end of the filter array, and client data longer than `H5Z_COMMON_CD_VALUES` leaked its allocation. `H5Pmodify_filter()` now fails with "filter not in pipeline" in this case.

### Stopped exporting the built-in filter class structs

   The class structs of the built-in filters (H5Z_DEFLATE, H5Z_SHUFFLE, H5Z_FLETCHER32,
   H5Z_NBIT, H5Z_SCALEOFFSET, and H5Z_SZIP) were exported from the shared library. Filter
   plugins built from a copy of HDF5's filter source, such as netCDF-C's deflate, shuffle,
   and fletcher32 plugins, define globals with the same names, and on ELF platforms the
   plugin's references to its own struct were resolved to the library's copy instead. The
   structs are now static to their source files, so a plugin always uses its own.

### Fixed out-of-bounds reads when a filtered chunk is shorter than its filter header

   The scaleoffset and szip filters each store a fixed-size header in front of the chunk data: a 21-byte parameter block for scaleoffset and a 4-byte uncompressed-length header for szip. On read, each one subtracted that fixed size from the chunk length without first checking that the chunk was at least that long. A truncated or corrupted chunk record made the subtraction wrap around, so both filters read far past the end of the chunk buffer. Its bounds checks also measured the chunk buffer's allocated size, which the library deliberately sizes to hold the larger unfiltered chunk, so a truncated chunk could still decompress out of the uninitialized remainder of that allocation. Both filters now reject any chunk shorter than their own header, and scaleoffset validates every read against the number of bytes actually stored for the chunk rather than the size of the buffer holding them. The fletcher32 filter now also rejects a chunk that holds only its 4-byte checksum and no data, which previously reached the checksum routine with a length of zero.

   Fixes CVE-2026-120754 and CVE-2026-120755

### Fixed a heap buffer over-read in scale-offset decode

   The scale-offset filter's decode path used the size computed from the user's filter
   parameters for the decompressed output without checking it against the actual
   compressed chunk. This caused a heap out-of-bound read when encountered a malformed
   file. The issue is now fixed with bound guards.

   Fixes CVE-2026-19029

### Fixed a deadlock in the ROS3 VFD on Windows

   When an HDF5 application running on Windows and using the ROS3 VFD exited normally,
   a deadlock would occur when the VFD called the aws-c-s3 library's cleanup function
   during process shutdown. This was due to the aws-c-s3 library attempting to join
   threads while the Windows loader lock was held. As a temporary workaround for Windows
   builds of the library, the aws-c-s3 cleanup logic has been moved to the VFD's
   termination callback (other platforms still use an atexit() handler) and will be
   skipped if the VFD determines that the process is being shutdown. Due to the current
   architecture of the library, the aws-c-s3 library's resources can only be properly
   cleaned up if the HDF5 application makes sure to call H5close() before exiting.
   Otherwise, memory leaks and other resource cleanup issues may be observed.

   Fixes GitHub issue #6560

### Fixed a heap buffer over-read when traversing a malformed external link

   The default external link traversal callback located the target file name and object
   path inside the link's user data with `strlen()`, without checking that the buffer was
   NULL-terminated or large enough to hold both strings. A corrupted or fuzzed file whose
   external link data was not properly terminated caused a read past the end of the `udata`
   buffer. `H5L__extern_traverse()` now validates the buffer against its stored size before
   parsing, the same way `H5Lunpack_elink_val()` does.

   Fixes CVE-2026-120757

### Fixed the page buffer's minimum metadata threshold failure to protect B-tree, local heap and object header metadata pages

The page buffer charges every page it holds to either `raw_count` or `meta_count`, counting `H5F_MEM_PAGE_DRAW` and `H5F_MEM_PAGE_GHEAP` pages as raw data and every other page as metadata. The minimum metadata reservation set by `H5Pset_page_buffer_size()` was not written as the complement of that test: it compared the page's type for equality with `H5F_MEM_PAGE_META`, which is an alias for `H5F_MEM_PAGE_SUPER`. A page entry's type is copied verbatim from the memory type of the access that brought the page into the buffer, so B-tree, local heap and object header pages carried other values and were evicted by raw data regardless of `min_meta_perc`, while still counting toward the threshold the reservation was measured against. In practice the reservation protected only the superblock and driver information pages. The classification is now made in one place, `H5MF_mem_page_type_is_raw()`, alongside its `H5F_mem_t` counterpart `H5MF_mem_type_is_raw()`, and both the page counts and the two reservations use it, so the metadata reservation protects the same population that `meta_count` measures.

Fixes GitHub issue #6679.

### Fixed the page buffer corrupting its page counts when a global heap page is freed

`H5PB_remove_entry()` is documented as never being given a raw data page, and it decremented `meta_count` unconditionally on that basis. Its only caller, `H5MF__sect_small_merge()`, excluded `H5FD_MEM_DRAW` but not `H5FD_MEM_GHEAP`, so a freed global heap page could reach it. Such a page is charged to `raw_count` rather than `meta_count` by `H5PB__insert_entry()`, because `H5MF__alloc_pagefs()` passes the allocation type to `H5PB_add_new_page()`, and `H5PB_write()` reuses that entry without changing its type. Removing such a page therefore left `raw_count` too high and decremented `meta_count` for a page it had never counted. Both counts govern the minimum metadata and minimum raw data page protection, and because they are unsigned, `meta_count` could wrap and leave those reservations wrong for the remaining life of the file. The caller now excludes the global heap along with raw data, `H5PB_remove_entry()` asserts that the page it was given is metadata rather than silently accounting for a raw one, and every page count decrement in the page buffer asserts the count it is releasing is non-zero.

### Fixed a heap buffer overflow when decoding object header messages

   The size stored in an object header message header was checked against the chunk before the rest of that message header was decoded, allowing a message body to start up to four bytes further into the chunk than the check accounted for. A corrupted or fuzzed file could declare a size that passed the check and still extended past the end of the chunk image, and the message's decode callback was then handed a buffer end outside the allocation. `H5O__chunk_deserialize()` now checks the message size once the whole message header has been decoded.

   Fixes GitHub issue #6401 (CVE-2026-120756)

### Fixed memory leaks and ID reference count issues when pushing an error to an error stack that is full

   When an error is pushed to an error stack, the library may make a copy of the file
   and function strings to ensure that they exist for the same duration as the error
   stack entry. When an error stack is full, the library simply makes any further pushes
   no-ops, but previously gave no information to calling code that this happened. This
   caused calling code to assume that the duplicated strings were owned by an error stack
   entry that was never pushed, leaking the duplicated strings. Additionally, IDs
   associated with the error stack entry were left with incremented reference counts,
   resulting in an infinite loop while closing the library.

### Library shutdown no longer aborts on a detected infinite loop

   When the library detects that it cannot make progress closing itself (an "infinite loop closing library"), it no longer calls `abort()`. The abort behaved inconsistently, only firing when automatic error message display was enabled. Additionally, terminating the entire host process on a shutdown-time condition is undesirable for applications that embed HDF5. The library now reports the condition (when error display is enabled) and returns without aborting.

   Fixes GitHub issue #6531

### Added pre-allocation validation for metadata cache entry image sizes

   Metadata cache entries with non-speculative load sizes are now checked against the file's end-of-allocation address before allocating the on-disk image buffer. Object header continuation messages also validate their decoded address and size fields before queuing continuation chunks. SWMR readers skip the end-of-allocation checks for both speculative and non-speculative metadata loads because their local end-of-allocation address may lag behind the writer.

### Fixed a crash when reading a chunked dataset whose chunk rank does not match the dataspace rank

   The chunk layout's stored dimensionality was validated against the dataspace rank at creation time, but not at open time, so a file whose stored chunk rank disagreed with its dataspace rank was not caught. The resulting inconsistent selection ranks during chunk I/O caused a divide-by-zero in the hyperslab iterator. The chunk dimensionality is now also validated on open, and such a dataset is rejected with an error instead of crashing.

   Fixes GitHub issue #6491

   Fixes CVE-2026-19025

### Fixed signed integer overflow in the scale-offset filter for full-range data

   When a signed-integer dataset filtered with scale-offset contained values spanning the full range of the datatype, the filter's calculation of the difference between the maximum and minimum values would overflow, resulting in undefined behavior. The difference is now computed in the unsigned domain, producing the correct result without triggering an overflow.

   Fixes GitHub issue #5861

### Fixed silent truncation of filtered chunk sizes with a small file "size of sizes"

   For all chunk index types in version-5 chunk layout messages, and for the single chunk index in any version of the chunk layout message, the on-disk size of a filtered chunk is encoded in a fixed-width field equal to the file's "size of sizes" (set via `H5Pset_sizes()`). The encode check assumed this field was always 8 bytes, so when the size of sizes was set to 2 or 4 an oversized chunk had its encoded size silently truncated (e.g., 160000 encoded in 2 bytes became 160000 & 0xFFFF = 28928), silently corrupting the chunk. The library now verifies that a filtered chunk's size fits in the file's size of sizes and reports an error at write time instead.

   Fixes GitHub issue #6023

### Fixed a crash when reading a dataset with a malformed fill value

   An old-style (either version 1 or version 2) fill value message that is marked "defined" but encodes a negative size leaves the fill value with a negative size and no datatype; `H5Pget_fill_value()` then passed that NULL datatype to `H5T_path_find()` and dereferenced it. `H5P_get_fill_value()` now rejects a fill value that has no datatype and returns an error, so the dataset itself remains readable while the corrupt fill value is reported cleanly.

   Fixes GitHub issue #6487

   Fixes CVE-2026-19024

### Fixed a crash when unprotecting a local heap with no cached prefix or data block

   `H5HL_protect()` pins one metadata cache entry for a local heap -- either the prefix when the heap is a single cache object, or the data block otherwise -- and `H5HL_unprotect()` unpins it again. The cache unlinks that entry from the heap when it destroys it, so a damaged file could reach `H5HL_unprotect()` with nothing to unpin, which triggered an assertion failure in debug builds and a NULL pointer dereference otherwise. `H5HL_unprotect()` now reports an error instead, and does so before decrementing the heap's protect count so that a rejected call leaves the heap unchanged rather than half unprotected with its cache entry still pinned.

   Fixes CVE-2026-120758

### Fixed crashes when reading datasets with malformed N-Bit or Fletcher32 filter metadata

   Reading a dataset from a corrupted or maliciously crafted file could crash the library in the N-Bit and Fletcher32 filter decode paths. The N-Bit filter dereferenced its client-data parameter array before validating it, crashing when the array was empty or NULL, and walked the compressed chunk during decompression without bounding the input against the chunk size, causing out-of-bounds reads. It also indexed that parameter array at offsets taken from the datatype description held in the array itself, without bounding those offsets against the number of parameters supplied, so a parameter list stopping short of the datatype it described was read past its end. The Fletcher32 filter subtracted the 4-byte checksum length from the chunk size without checking that the chunk was at least that large, underflowing the length passed to the checksum routine. These filters now validate their parameters and buffer sizes and fail with an error instead of crashing.

   Fixes GitHub issues #6489 and #6492 (CVE-2026-19026 and CVE-2026-19027)
   
   Fixes GitHub issues #6488 and #6490 (CVE-2026-19028)

### Fixed a stack overflow when iterating a corrupted B-tree

   `H5B__iterate_helper()` now verifies that a B-tree node it has just protected has the level the traversal expects, when the expected level is known. The equivalent check in `H5B__cache_deserialize()` only runs when a node is first loaded into the metadata cache, so a corrupted B-tree whose child pointer revisits a node that is already cached (for example, a node that points to itself) could bypass that check and recurse without bound until the stack was exhausted. Such a file is now rejected with an error instead of crashing. This was observed through `H5Gget_info()`.

   Fixes GitHub issue #6403 (CVE-2026-120689)

## Java Library

### Fixed a build ordering issue when the `HDF5_ENABLE_MAVEN_DEPLOY` option is enabled

   With the `HDF5_ENABLE_MAVEN_DEPLOY` option enabled, the Java test programs under
   `java/src-jni/test` previously had an incorrect dependency tree that could result
   in build failures. The test programs would get built before the platform-specific
   JAR file created for Maven was copied to the more generic "jarhdf5-<version>.jar"
   name which the test programs depended on. Building of those test programs is now
   deferred until the copying step has completed.

   Fixes GitHub issue #6748

### Fixed datatype ID leaks when reading or writing nested datatypes through the JNI

   The object-tree read and write helpers in the JNI derived a base datatype from the memory type with `H5Tget_super()` for the variable-length, array and complex classes, but never closed it. Because an `hid_t` is not reclaimed when a native method returns, every read or write of such data leaked at least one datatype ID for the lifetime of the process, and a nested type leaked one per level. The helpers now close the derived type on both the success and error paths.

   Fixes GitHub issue #6592

## Configuration

### Fixed h5cc, h5c++ and h5fc in the glibc 2.28 and Intel Linux binaries

   The wrappers run the compiler CMake recorded at configure time, by default as an absolute
   path. The wrappers in the glibc 2.28 Linux binary failed looking for
   `/opt/rh/gcc-toolset-14/root/usr/bin/cc`, which exists only in its build container, and
   those in the Intel Linux binary needed exactly `/opt/intel/oneapi/compiler/2025.0/bin/icx`.
   These binaries now record the compiler names (`gcc`, `g++`, `gfortran` and `icx`, `icpx`,
   `ifx`) through `HDF5_H5CC_C_COMPILER`, `HDF5_H5CC_CXX_COMPILER` and
   `HDF5_H5CC_Fortran_COMPILER`, so the wrappers run the compiler found on `PATH`. A build from
   source still records the absolute path unless these options are set.

   The wrappers also honor environment variables to run a different compiler: `HDF5_CC` for
   `h5cc`, `HDF5_CXX` for `h5c++` and `HDF5_FC` for `h5fc`, as the Autotools wrappers did, and
   `HDF5_PCC` for `h5pcc` and `HDF5_PFC` for `h5pfc`. For example, `HDF5_CC=clang h5cc foo.c`.
   Unlike the Autotools wrappers, the parallel wrappers do not read `HDF5_CC` or `HDF5_FC`, so
   setting one for a serial installation does not change a parallel one.

   The release CI now compiles and runs C, C++ and Fortran programs with the glibc 2.28 binary
   (outside its build container) and the Intel Linux binary, checks that their wrappers record
   no absolute compiler path, and checks `pkg-config --define-prefix` on them.

### Fixed pkg-config and the compiler wrappers when HDF5_LIB_INFIX is set

   With `HDF5_LIB_INFIX` set, for example to `_openmpi`, the pkg-config files were still installed as `hdf5.pc`, `hdf5_hl.pc` and so on, while their `Name` and `Requires` fields, and the compiler wrappers, used the name with the infix (`hdf5_openmpi`). `h5cc` and the other wrappers failed with "Package hdf5_openmpi was not found", and `pkg-config hdf5_hl` could not resolve its requirement. The pkg-config files are now named after the library (`hdf5_openmpi.pc`, `hdf5_openmpi_hl.pc`, ...), and `libhdf5.settings` is installed as `libhdf5_openmpi.settings`, which `h5cc -showconfig` reads.

   The pkg-config file names also include `HDF5_EXTERNAL_LIB_PREFIX` and `HDF5_EXTERNAL_LIB_SUFFIX`, since they are part of the library name. For example, with `HDF5_EXTERNAL_LIB_PREFIX=vtk` the files are now `vtkhdf5.pc` and `vtkhdf5_hl.pc` instead of `hdf5.pc` and `hdf5_hl.pc`, so the `Requires: vtkhdf5` line in the high-level file can now be resolved.

   Builds with different infixes (for example serial, Open MPI and MPICH) can now share a library directory. Their other install directories must still differ per build: set `HDF5_INSTALL_INCLUDE_DIR`, `HDF5_INSTALL_CMAKE_DIR`, `HDF5_INSTALL_MODULE_DIR` and `HDF5_INSTALL_BIN_DIR` for each one, or the headers, CMake package files, Fortran modules and compiler wrappers of one build overwrite those of another.

   Compatibility: with an infix set, `pkg-config hdf5` no longer finds the library. Use `pkg-config hdf5<infix>`, for example `pkg-config hdf5_openmpi`. Builds with no infix, prefix or suffix install the same files as before.

### Fixed "Extra libraries" in libhdf5.settings and the built-in settings

  `libhdf5.settings` listed the extra libraries separated by semicolons, and
  the settings compiled into the library (printed when `H5check_version()`
  detects a version mismatch) used a different list that contained CMake
  target names such as `Threads::Threads` and left out the compression
  libraries. Both now list the same libraries as linker flags,
  separated by spaces, for example `-lm -ldl -lz`.

### Fixed version handling in installed CMake package version configuration file

   The installed CMake package version configuration file for the library previously used `SameMinorVersion` for the version compatibility logic, causing a `find_package(HDF5 X.Y.Z)` call to fail unless the version of a located HDF5 installation matched both `X` and `Y` of the version number exactly (i.e., releases with a greater minor version number weren't considered backward compatible). This reflected the version compatibility of HDF5 releases prior to version 2.0.0, but doesn't reflect the version compatibility of HDF5 version 2.0.0+ releases. The version compatibility logic now uses `SameMajorVersion`, so a `find_package(HDF5 X.Y.Z)` call will accept all versions of HDF5 where the major version matches `X` (i.e., only releases with a greater major version number will be rejected as not backward compatible).

### Fixed the C++ examples failing to compile when built standalone

  The standalone examples build used C++98, but `H5public.h` includes
  `<cinttypes>`, which requires C++11. This affected any C++ translation unit
  including `hdf5.h`, and did not match the HDF5 C++ library itself, which is
  built as C++11. The C++ examples did not compile, against either static or
  shared HDF5. The examples are now built as C++11.

  Only the standalone build was affected. Examples built as part of the HDF5
  build inherit the library's own C++ standard.

### Fixed the examples skipping the HL, Fortran and C++ programs in some configurations

  When built standalone against an installed HDF5, the examples chose between
  the shared and static HL, Fortran and C++ libraries using `BUILD_SHARED_LIBS`,
  while the C library used `H5EXAMPLE_USE_SHARED_LIBS`. Since
  `H5EXAMPLE_USE_SHARED_LIBS` determines which component is requested from
  `find_package`, and therefore which `HDF5_<linkage>_<lang>_FOUND` variables
  exist, `BUILD_SHARED_LIBS` could not select a linkage on its own. With
  `H5EXAMPLE_USE_SHARED_LIBS` on and `BUILD_SHARED_LIBS` unset, those examples
  were disabled with a "libs not found" message even though the libraries were
  installed and had been found. The selection now uses
  `H5EXAMPLE_USE_SHARED_LIBS`, matching the C library.

  Builds driven through `CTestScript.cmake` were not affected, since its cache
  file forces `BUILD_SHARED_LIBS` on. This affected cases where the examples
  were built directly without that cache file.

### Fixed the Fortran and C++ information reported in the build settings

The "Shared/Static Fortran Library" and "Shared/Static C++ Library" lines in `libhdf5.settings` and in the build settings string compiled into the library reused the C library values, so they reported `YES` even when `HDF5_BUILD_FORTRAN` or `HDF5_BUILD_CPP_LIB` was off. These lines now report `NO` unless that language's library is built. The "Fortran Compiler", "Module Directory" and "C++ Compiler" lines are now also left empty when that language's library is not built.

Fixes #5723.

## Tools

### Fixed a double free in h5repack

   The tool h5repack produced a double free crash on a malicious HDF5 file in copy_refs_attr()
   while duplicating reference-valued attributes.  Some cleanup was done to remove the
   double free and memory leaks.

   Fixes CVE-2026-102935

### Fixed an issue with quoting of data values in h5ls and h5dump when displaying as ASCII characters

   When using the `-s` (h5ls) or `-r` (h5dump) option to display 1-byte integer datasets and
   attributes as ASCII characters, a closing double-quote character for data values was dropped
   in some cases. This double-quote character has been restored and similar formatting issues
   have been fixed for cases where elements wrap to new lines according to the particular tool's
   column limit setting.

### Fixed a crash in h5dump binary output of variable-length string datasets

   Dumping a variable-length string dataset with more than one element to native binary (`h5dump -b`) could crash. `render_bin_output()` reused a single variable as both the per-element stride and the length of the current string, so after the first element the stride was corrupted and subsequent elements were read from misaligned addresses, dereferencing a garbage pointer. The two uses are now kept separate and variable-length string datasets can be binary dumped safely.

   Fixes GitHub issue #6486

   Fixes CVE-2026-19023

## Performance

## Fortran API

### h5open_f now re-initializes the Fortran interface after h5close_f

   An h5open_f / h5close_f / h5open_f sequence could leave the Fortran interface
   uninitialized. The second h5open_f reported success, but the predefined type
   handles were left holding identifiers that h5close_f had released, so later calls
   failed. Whether this happened depended on the Fortran compiler.

   Fixes GitHub issue #6642

### h5fget_obj_ids_f no longer returns the Fortran interface's own identifiers

   h5fget_obj_count_f excludes the objects h5open_f opens to represent the predefined
   types, but h5fget_obj_ids_f returned them, so the two disagreed about the same query
   and an application walking the list found datatypes it never opened. Both now report
   only what the application has open, matching the C API.

   Fixes GitHub issue #6648

### h5fget_obj_count_f and h5fget_obj_ids_f document their object type argument

   Both listed the object types as alternatives without mentioning that they may be
   combined with IOR(), which the C API supports and both have always passed through.

### h5fget_obj_count_f no longer returns negative counts

   With the Fortran interface open, counting a single object type across all files
   subtracted the objects opened by h5open_f, so queries for files, groups, and
   datasets returned a negative count and reported success. A negative count is now
   reported as an error.

## High-Level Library

### Fixed leaked identifiers in H5DSattach_scale()

   When attaching a dimension scale that already had one or more datasets
   attached to it, `H5DSattach_scale()` rewrote the scale's `REFERENCE_LIST`
   attribute without releasing everything it had acquired to do so. It reopened
   each reference in the existing list with `H5Ropen_object()` but only closed
   the resulting identifier on the error path, and it destroyed neither the
   references it read from the old attribute nor the one it appended to the new
   one -- the buffer being written was reclaimed with the old, one element
   shorter, dataspace. Every one of those kept the file open, so a later
   `H5Fcreate()` with `H5F_ACC_TRUNC` on the same file failed with "unable to
   truncate a file which is already open", an error with nothing in it to point
   back at a dimension scale.

   The identifier is now closed on the success path as well, and both reference
   buffers are reclaimed, matching the equivalent code in
   `H5DSdetach_scale()`. This code is only reached when `H5DSwith_new_ref()`
   selects the new-style reference path, which happens when the object's
   terminal VOL connector is not the native one -- a pass-through connector
   stacked over the native connector does not qualify -- or when the library is
   built with `H5_DIMENSION_SCALES_WITH_NEW_REF`; the old-style reference
   path opens nothing.

## Fortran High-Level APIs

## Documentation

### Clarified that direct chunk writes must supply an entire chunk

   The documentation for `H5Dwrite_chunk()` and `H5DOwrite_chunk()` did not state that the
   buffer must encode an entire chunk. Before filtering, a chunk always holds every element
   covered by the chunk dimensions, including the elements of a partial edge chunk that lie
   outside the dataspace. A precompressed chunk must therefore be the compressed form of the
   full chunk, not only of the elements inside the dataspace. Since HDF5 2.2.0, the library
   checks that a filtered chunk unfilters to exactly the full chunk size, so a filtered chunk
   written without its edge padding can no longer be read with `H5Dread()`. The documentation
   and the file format specification now state this requirement explicitly.

## F90 APIs

## C++ APIs

## Testing

### Fixed a link failure of the Fortran tests when built with link-time optimization

   `testhdf5_fortran` failed to link with an undefined reference to
   `test_append_flush_callback` when built with LTO (`-flto`), which is enabled by default
   on Fedora, RHEL, openSUSE, and Ubuntu. `gfortran` versions prior to 15.3 (without the
   fix for GCC PR 117303) drop a procedure when its `C_FUNLOC` is passed directly as an
   argument. The test now assigns `C_FUNLOC` to a variable first, so distributions no
   longer need to build Fortran without LTO.

### Fortran test programs no longer exit successfully after a fatal error

   The Fortran tests ended unrecoverable failures with STOP, which exits with a
   success status, so a run that aborted part way through was reported as passing.

### New test for the object count and identifier list

   The Fortran tests had no coverage of h5fget_obj_ids_f over all files, and none that
   compared it against h5fget_obj_count_f. A new test opens objects of several types
   and checks that the two agree, that object types combined with IOR() count as the
   sum of their parts, and that a buffer shorter than the number of open objects is
   filled with the application's own.

### The h5open/h5close test checks that the interface re-initializes

   Its object counts were taken while the Fortran interface was closed, where no such
   call is permitted. They now run after the interface has been reopened, and confirm
   that the predefined types are usable again.

# ✨ Support for new platforms and languages

# ☑️ Platforms Tested

A table of platforms tested can be seen on the [wiki](https://github.com/HDFGroup/hdf5/wiki/Platforms-Tested).
Current test results are available [here](https://my.cdash.org/index.php?project=HDF5).

# ⛔ Known Problems

- The h5fuse tool will not work in parallel mode in this release.  h5fuse in serial mode is unaffected.

- When performing implicit datatype conversion on specific non-IEEE floating-point format data, HDF5 may improperly convert some data values:

   When performing I/O operations using a non-IEEE floating-point format datatype, HDF5 may improperly convert some data values due to incomplete handling of non-IEEE types. Such types include the following pre-defined datatypes:

    H5T_FLOAT_F8E4M3
    H5T_FLOAT_F8E5M2
    H5T_FLOAT_F6E2M3
    H5T_FLOAT_F6E3M2
    H5T_FLOAT_F4E2M1

   If possible, an application should perform I/O with these datatypes using an in-memory type that matches the specific floating-point format and perform explicit data conversion outside of HDF5, if necessary. Otherwise, read/written values should be verified to be correct.

- When the library detects and builds in support for the _Float16 datatype, an issue has been observed on at least one MacOS 14 system where the library fails to initialize due to not being able to detect the byte order of the _Float16 type [#4310](https://github.com/HDFGroup/hdf5/issues/4310):

     #5: H5Tinit_float.c line 308 in H5T__fix_order(): failed to detect byte order
     major: Datatype
     minor: Unable to initialize object

   If this issue is encountered, support for the _Float16 type can be disabled with a configuration option:

     `CMake: HDF5_ENABLE_NONSTANDARD_FEATURE_FLOAT16=OFF`

- When HDF5 is compiled with NVHPC versions 23.5 - 23.9 (additional versions may also be applicable) and with -O2 (or higher) and -DNDEBUG, test failures occur in the following tests:

   - H5PLUGIN-filter_plugin
   - H5TEST-flush2
   - H5TEST-testhdf5-base
   - MPI_TEST_t_filters_parallel

  Sporadic failures (even with lower -O levels):

   - Java JUnit-TestH5Pfapl
   - Java JUnit-TestH5D

  Also, NVHPC will fail to compile the test/tselect.c test file with a compiler error of `use of undefined value` when the optimization level is -O2 or higher.

   This is confirmed to be a [bug in the nvc compiler](https://forums.developer.nvidia.com/t/hdf5-no-longer-compiles-with-nv-23-9/269045) that has been fixed as of 23.11. If you are using an affected version of the NVidia compiler, the work-around is to set the optimization level to -O1.

- CMake files do not behave correctly with paths containing spaces

   Do not use spaces in paths because the required escaping for handling spaces results in very complex and fragile build files.

- At present, metadata cache images may not be generated by parallel applications. Parallel applications can read files with metadata cache images, but since this is a collective operation, a deadlock is possible if one or more processes do not participate.

- The subsetting option in `ph5diff` currently will fail and should be avoided

   The subsetting option works correctly in serial `h5diff`.

- Flang Fortran compilation will fail (last check version 17) due to not yet implemented: (1) derived type argument passed by value (H5VLff.F90), and (2) support for REAL with KIND = 2 in intrinsic SPACING used in testing.

- Fortran tests HDF5_1_8.F90 and HDF5_F03.F90 will fail with Cray compilers greater than version 16.0 due to a compiler bug. The latest version verified as failing was version 17.0.

- Several tests currently fail on certain platforms:
   MPI_TEST-t_bigio fails with spectrum-mpi on ppc64le platforms.

   MPI_TEST-t_subfiling_vfd and MPI_TEST_EXAMPLES-ph5_subfiling fail with
   cray-mpich on theta and with XL compilers on ppc64le platforms.

- File space may not be released when overwriting or deleting certain nested variable length or reference types.

Known problems in previous releases can be found in the HISTORY*.txt files in the HDF5 source. Please report any new problems found to <a href="mailto:help@hdfgroup.org">help@hdfgroup.org</a>.
